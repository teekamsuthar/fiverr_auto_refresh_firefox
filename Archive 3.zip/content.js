// Content script for Fiverr pages (currently no specific action needed)
console.log("Fiverr Refresher content script loaded."); 